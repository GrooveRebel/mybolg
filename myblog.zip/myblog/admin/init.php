<?php
include_once '../configs/config.php';
include_once '../common/function.php';

?>