<?php
include_once "header.php";
$id = filterstr($_GET['id']);
$result = $conn->query("select * from flink where id='$id'");
$row = $result->fetch_assoc();

if ($_POST['sub']) {
	$title = filterstr($_POST['title']);
    $url = filterstr($_POST['url']);
	// $content = filterstr($_POST['content']);
	// $author = filterstr($_POST['author']);
	// $keyword = filterstr($_POST['keyword']);
	// $c_time = time();
	// $catid = filterstr($_POST['catid']);
	// echo "update article set title='$title',content='$content',author='$author',keyword='$keyword',c_time=$c_time,catid=$catid where id='$id'";
	$conn->query("update flink set url_name='$title',url='$url' where id = '$id'");
	if ($conn->affected_rows > 0) {
		header('location:flink_list.php');
	} else {
		echo "<script>alert('修改友链失败')</script>";
	}

}

?>


<!doctype html>
<!-- <html>
<head>
    <meta charset="UTF-8"/>
    <title>后台管理</title>
    <link rel="stylesheet" type="text/css" href="css/common.css"/>
    <link rel="stylesheet" type="text/css" href="css/main.css"/>
</head>
<body>
<div class="topbar-wrap white">
    <div class="topbar-inner clearfix">
        <div class="topbar-logo-wrap clearfix">
            <h1 class="topbar-logo none"><a href="index.html" class="navbar-brand">后台管理</a></h1>
            <ul class="navbar-list clearfix">
                <li><a class="on" href="index.html">首页</a></li>
                <li><a href="#" target="_blank">网站首页</a></li>
            </ul>
        </div>
        <div class="top-info-wrap">
            <ul class="top-info-list clearfix">
                <li><a href="#">管理员</a></li>
                <li><a href="#">修改密码</a></li>
                <li><a href="#">退出</a></li>
            </ul>
        </div>
    </div>
</div>
<div class="container clearfix">
    <div class="sidebar-wrap">
        <div class="sidebar-title">
            <h1>菜单</h1>
        </div>
        <div class="sidebar-content">
            <ul class="sidebar-list">
                <li>
                    <a href="#"><i class="icon-font">&#xe003;</i>常用操作</a>
                    <ul class="sub-menu">
                        <li><a href="article_list.php"><i class="icon-font">&#xe005;</i>博文管理</a></li>
                        <li><a href="design.html"><i class="icon-font">&#xe006;</i>分类管理</a></li>
                        <li><a href="design.html"><i class="icon-font">&#xe052;</i>友情链接</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#"><i class="icon-font">&#xe018;</i>系统管理</a>
                    <ul class="sub-menu">
                        <li><a href="system.html"><i class="icon-font">&#xe017;</i>系统设置</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div> -->
    <!--/sidebar-->
    <div class="main-wrap">

        <div class="crumb-wrap">
            <div class="crumb-list"><i class="icon-font"></i><a href="main.php">首页</a><span class="crumb-step">&gt;</span><a class="crumb-name" href="flink_list.php">友链管理</a><span class="crumb-step">&gt;</span><span>修改友链</span></div>
        </div>
        <div class="result-wrap">
            <div class="result-content">
                <form action="" method="post" id="myform" name="myform" enctype="multipart/form-data">
                    <table class="insert-tab" width="100%">
                        <!-- <tbody><tr>
                            <th width="120"><i class="require-red">*</i>分类：</th>
                            <td>
                                <select name="catid" id="catid" class="required">
                                    <option value="">请选择</option>
                                <?php
                                    $cate_result = $conn->query("select * from cate");
                                    while ($row1 = $cate_result->fetch_assoc()) {
                                        $selected = $row['catid'] == $row1['id'] ? "selected" : null;
	                            ?>
                                        <option <?php echo $selected; ?> value="<?php echo $row1['id'] ?>"><?php echo $row1['class_name'] ?></option>
                                <?php
                                    }
                                ?>
                                </select>
                            </td>
                        </tr> -->
                            <tr>
                                <th><i class="require-red">*</i>网站名称：</th>
                                <td>
                                    <input class="common-text required" id="title" name="title" size="50" value="<?php echo $row['url_name'] ?>" type="text">
                                </td>
                            </tr>
                            <tr>
                                <th>URL：</th>
                                <td><input class="common-text" name="url" size="50" value="<?php echo $row[url] ?>" type="text" placeholder="输入关键字以空格或则逗号隔开"></td>
                            </tr>
                            
                            <tr>
                                <th></th>
                                <td>
                                    <input class="btn btn-primary btn6 mr10" value="提交" type="submit" name="sub">
                                    <input class="btn btn6" onClick="history.go(-1)" value="返回" type="button">
                                </td>
                            </tr>
                        </tbody></table>
                </form>
            </div>
        </div>

    </div>
    <!--/main-->
</div>
<!-- <script type="text/javascript" src="ueditor/ueditor.config.js"></script>
<script type="text/javascript" src="ueditor/ueditor.all.min.js"></script>
<script type="text/javascript" src="ueditor/lang/zh-cn/zh-cn.js"></script>

<script type="text/javascript" charset="utf-8">//初始化编辑器
    window.UEDITOR_HOME_URL = "ueditor/";//配置路径设定为UEditor所放的位置
    window.onload=function(){
        /* window.UEDITOR_CONFIG.initialFrameHeight=600;//编辑器的高度*/
        /* window.UEDITOR_CONFIG.initialFrameWidth=1200;//编辑器的宽度*/
        var editor = new UE.ui.Editor({
            imageUrl : '',
            fileUrl : '',
            imagePath : '',
            filePath : '',
            imageManagerUrl:'', //图片在线管理的处理地址
            imageManagerPath:''
        });
        editor.render("content");//此处的content与<textarea name="content" id="content">的id值对应 </textarea>
    }
</script> -->
</body>
</html>