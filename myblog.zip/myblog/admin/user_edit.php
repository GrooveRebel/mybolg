<?php
include_once "header.php";

// 设置默认的样式
// $style = "background-color: #f2f2f2; padding: 10px;";

if($_SERVER["REQUEST_METHOD"] == "POST") {
    // 获取用户输入的旧密码、新密码和确认新密码
    $old_password = filterstr(md5($_POST['old_password']));
    $new_password = filterstr(md5($_POST['new_password']));
    $confirm_password = filterstr(md5($_POST['confirm_password']));
    $username = $_SESSION['username'];
    // echo $username;
    // echo $old_password;
    // 检查旧密码是否正确
    $result=$conn->query("select * from users where username='$username'");
    $current_password = $result->fetch_assoc();
    // var_dump($current_password);
    // echo $current_password[password];
    
    if($old_password != $current_password[password]) {
        echo "<script>alert('旧密码错误')</script>";
    } else if($new_password != $confirm_password) {
        // 检查新密码和确认新密码是否匹配
        echo "<script>alert('新密码和确认新密码不匹配')</script>";
    } else {
        // 更新密码
        $conn->query("update users set password='$new_password' where username='$username'");
        if($conn->affected_rows>0){
            echo "<script>alert('修改密码成功');location.href='main.php'</script>";
        }else{
            echo "<script>alert('修改密码失败')</script>;";
        }
        // 在此处将新密码哈希值保存到数据库或文件中，替换当前密码

    }
}
?>

<!-- 在 HTML 表单中包含样式 -->
<!DOCTYPE html>
<html>
<head>
    <title>修改密码</title>

</head>
<body>
    <h2>修改密码</h2>
    <form method="post">
        <label for="old_password">旧密码：</label>
        <input type="password" name="old_password" required><br>
        <label for="new_password">新密码：</label>
        <input type="password" name="new_password" required><br>
        <label for="confirm_password">确认新密码：</label>
        <input type="password" name="confirm_password" required><br>
        <input type="submit" value="提交">
    </form>
</body>
</html>
