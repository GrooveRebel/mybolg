<?php
include_once 'init.php';
if ($_POST['sub']) {		
	$username = filterstr(($_POST['username']));
	$password = filterstr((md5($_POST['password'])));
	$result = $conn->query("select * from users where username='$username' and password='$password'");
	// var_dump($result);
	if ($result->num_rows > 0) {
		$row = $result->fetch_assoc(); //获取关联数组（数据库查询的值）
		// var_dump($row); //打印内容
		if ($row['password'] == $password) {
			echo "登录成功";
			$_SESSION['username'] = $row[username];  //登录成功后将用户名给session
			header('location:main.php');
			$conn->close();
		} else {
			echo "<script>alert('用户或密码错误')</script>";}

	} else {
		echo "<script>alert('登录失败')</script>";}

}

?>

<!doctype html>
<html>
<head>
    <meta charset="UTF-8"/>
    <title>『MayFly博客』后台管理</title>
	<link rel="stylesheet" type="text/css" href="css/admin_login.css"/>
	<script>
			function check(form){
				var username=form.username.value;
				if(username.length==0){
					alert('用户名不能为空');
					form.username.focus();
					return false;
				}
				var password=form.password.value;
				if(password.length==0){
					alert('密码不能为空');
					form.password.focus();
					return false;
				}
				return true;

			}
		</script>
</head>
<body>
<div class="admin_login_wrap">
    <h1>后台管理</h1>
    <div class="adming_login_border">
        <div class="admin_input">
            <form action="" method="post" onsubmit="return check(this)">
                <ul class="admin_items">
                    <li>
                        <label for="user">用户名：</label>
                        <input type="text" name="username" id="username" size="40" class="admin_input_style" />
                    </li>
                    <li>
                        <label for="pwd">密码：</label>
                        <input type="password" name="password" id="password" size="40" class="admin_input_style" />
                    </li>
                    <li>
                        <tr><td colspan="2"><input type="submit" value="登录" name="sub" class="btn btn-primary"></td></tr>
                    </li>
                </ul>
            </form>
        </div>
    </div>
    <!-- <p class="admin_copyright"><a tabindex="5" href="#" target="_blank">返回首页</a> &copy; 2014 Powered by 更多模板：<a href="http://www.mycodes.net/" target="_blank">源码之家</a></p> -->
</div>
</body>
</html>




<!-- <html>
	<head>
		<title>管理员登录</title>
		<style>
			.login{
				width:400px;
				margin: 0px auto;
			}
		</style>
		<script>
			function check(form){
				var username=form.username.value;
				if(username.length==0){
					alert('用户名不能为空');
					form.username.focus();
					return false;
				}
				var password=form.password.value;
				if(password.length==0){
					alert('密码不能为空');
					form.password.focus();
					return false;
				}
				return true;

			}


		</script>
	</head>
	<body>
		<div class="login">
			<form action="" method="POST" onsubmit="return check(this)">
			<table>
				<tr><td><label for username>用户</label></td><td><input type="text" name="username" id="username"></td></tr>
				<tr><td><label for password>密码</label></td><td><input type="password" name="password" id="password"></td></tr>
				<tr><td colspan="2"><input type="submit" value="登录" name="sub"></td></tr>
			</table>
			</form>

		</div>



	</body>

</html> -->