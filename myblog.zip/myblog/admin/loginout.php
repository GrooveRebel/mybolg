<?php
if(isset($_SESSION['user_id'])) {
    // 如果会话中有用户 ID，则销毁会话
    session_destroy();
    header("Location: login.php"); // 重定向到登录页面
} else {
    // 如果会话中没有用户 ID，则直接重定向到登录页面
    header("Location: login.php");
}

?>
