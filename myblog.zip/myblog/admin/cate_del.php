<?
// 导入连接数据库文件
require_once 'init.php';
//获取 index.php 传来的id参数并转换为整型
$id = intval($_GET['id']);
$sql = "delete from cate where ID=$id";
// mysqli_query($conn,$sql)，执行sql语句
// mysqli_affected_row($conn)，sql语句影响的记录数
if (mysqli_query($conn, $sql) && mysqli_affected_rows($conn) == 1) //ִ执行sql语句并判断执行是否成功
{
    // js代码：输出提示信息，并跳转到主页面
    echo "<script>alert('删除成功！');location.href='cate_list.php'</script>";
} else {
    echo "<script>alert('删除失败！');location.href='cate_list.php'</script>";
}