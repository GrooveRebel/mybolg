# Light Year Blog

#### 演示地址
[http://libs.itshubao.com/blog/](http://libs.itshubao.com/blog/)

#### 介绍
个人非常喜欢左右分栏的这种布局，加上左侧的背景图每天更换，让人有不一样的心情，从最初的到现在，大概这个是第四个版本的布局模板了，除了最早的一个模板，其他的也都分享出来了，这一个是最新的一个，属于博客类型的模板。

Light Year Blog是基于Bootstrap v4.3.1的小清新风格的HTML博客模板，只有三个页面，首页，详细页和About页面，样式和js都不多，比较简单。

1. 左右分栏布局，自己搭配左侧背景。
1. 基于 Bootstrap v4.3.1 编写，响应式布局（台式机、平板电脑、移动设备），支持主流浏览器（Chrome、Firefox、Safari、IE11、Edge）。
1. 界面设计简洁、清新。


#### 截图
![首页](https://images.gitee.com/uploads/images/2019/1103/214027_5dc5b629_82992.jpeg "未命名-1.jpg")
![详细页](https://images.gitee.com/uploads/images/2019/1103/214045_d7f79cef_82992.jpeg "笔下光年的博客.jpg")