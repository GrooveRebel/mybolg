<?php
function filterstr($value) {
	if (!get_magic_quotes_gpc()) {
		$value = addslashes(trim($value));
		return $value;
	}
	return $value;
}

?>