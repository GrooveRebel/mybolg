  <!-- 侧边栏 -->
  <div class="col-xl-4">
          <div class="lyear-sidebar">
            <!-- 热门文章 -->
            <aside class="widget widget-hot-posts">
              <div class="widget-title">热门文章</div>
              <?php
              $result=$conn->query("select * from article order by click desc limit 5");
              while($row=$result->fetch_assoc()){ 
              ?>
              <ul>
                <li>
                  <a href="post.php?id=<?php echo $row['id']?>"><?php echo $row['title']?></a> <span><?php echo date("Y/m/d H:i:s", $row['c_time']); ?></span>
                </li>
              </ul>
            <?php
                }
            ?>
            
            </aside>

            <!-- 归档 -->
            <aside class="widget">
              <div class="widget-title">友情链接</div>
              <?php
              $result=$conn->query("select * from flink");
              while($row=$result->fetch_assoc()){
              ?>
              <ul>
                <li><a href="<?php echo $row['url']?>"><?php echo $row[url_name]?></a></li>
              </ul>
            <?php
                }
            ?>
            </aside>

          </div>
        </div>
        <!-- 侧边栏 end -->