<?php
session_start();			//启用session
$username = "myblog";
$password = "P@ssw0rd";
$host = "localhost";
$dbname = "myblog";
$conn = mysqli_connect($host, $username, $password, $dbname);
if ($conn->connect_error) {
	die("连接数据库失败" . connect_error);
}
$conn->query('set names utf-8');

?>